#include "./Poop.hh"

Poop::Poop()
{}

Poop::Poop()
{}
