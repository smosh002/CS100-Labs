#!/bin/sh
declare -i t
ARRAY=(9 8 7 6 5 4 3 2 1)
for ((i=0; i<9; i++))
do
for ((j=$i; j<9; j++))
do
if [ ${ARRAY[i]} -gt ${ARRAY[j]} ]; then
t=${ARRAY[$i]}
ARRAY[$i]=${ARRAY[$j]}
ARRAY[$j]=$t
fi
done
done
echo ${ARRAY[*]}
