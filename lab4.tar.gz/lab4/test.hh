#ifndef test_hh
#define test_hh

class test
{
	public:
	test();
	~test();

	private()
}
