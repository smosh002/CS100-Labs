#ifndef Poop_hh
#define Poop_hh

class Poop
{
	public:
	Poop();
	~Poop();

	private()
}
