#!/bin/sh
touch main.cc
cat Sasha_861168870.txt >> main.cc
echo "int main(int argc, const char** argv)
	{}" >> main.cc
